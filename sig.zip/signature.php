<?php
$host = 'localhost';
$name = 'root';
$password = '';
$database = 'joc';

$player_name=$_GET['name']; //http://yourdomain.com/signature.php?name={Username}
try {
    $conn = new PDO("mysql:host=$host;dbname=$database", $name, $password); //Your database accounts etc
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }
catch(PDOException $e)
    {
    echo "Connection failed: " . $e->getMessage(); //Database fail
    }

$statement = $conn->prepare("select * from users where Username = :Username"); //Select accounts
$statement->execute(array(':Username' => $player_name));
if ($row = $statement->fetch(PDO::FETCH_OBJ)) {
    header('Content-Type: image/png;'); 
    $im = @imagecreatefrompng('adryan.png') or die("Cannot select the correct image. Please contact the webmaster."); //Background image
    $text_color = imagecolorallocate($im, 197,197,199);
    $color_white = imagecolorallocate($im, 255, 255, 255); //White Color
	$color_black = imagecolorallocate($im, 0, 0, 0); //Black color
	$colorRed = ImageColorAllocate($im, 116, 106, 105); //Color
	$colorOrange = ImageColorAllocate($im, 250, 165, 0); //Orange Color
	$colorGreen = ImageColorAllocate($im,0,500,0); //Green Color
	$colorHotRed = ImageColorAllocate($im, 227, 38, 54); //Hot Red Color
	$colorRED1 = ImageColorAllocate($im, 250, 0, 0); //Red Color
	$colorBlue = ImageColorAllocate($im, 0, 255, 255); //Blue
    $font = 'C:\xampp\htdocs\aciERankingu da\sig\arial.ttf'; //Font Text
	imagettftext($im, 10, 0.0, 20, 15, $color_white, $font, "Nick: " .$row->Username);
	imagettftext($im, 10, 0.0, 20, 30, $color_white, $font, "PlayerID: " .$row->PlayerID);
	imagettftext($im, 10, 0.0, 20, 45, $color_white, $font, "Rank: " .$row->PrivLevel);
	imagettftext($im, 10, 0.0, 20, 60, $color_white, $font, "First: " .$row->FirstCount);
	imagettftext($im, 10, 0.0, 20, 75, $color_white, $font, "Cheese(Profile): " .$row->CheeseCount);
	if($row->Gender == 2)
	imagettftext($im, 10, 0.0, 20, 90, $color_white, $font, "Sex : Male");
	if($row->Gender == 1)
	imagettftext($im, 10, 0.0, 20, 90, $color_white, $font, "Sex : Girl");
	if($row->Gender == 0)
	imagettftext($im, 10, 0.0, 20, 90, $color_white, $font, "Sex : N/A");
	if($row->BanHours == 0)
	imagettftext($im, 10, 0.0, 20, 105, $color_white, $font, "Ban : No");
	if($row->BanHours != 0)
	imagettftext($im, 10, 0.0, 20, 105, $colorHotRed, $font, "Ban : Yes");
	imagettftext($im, 10, 0.0, 20, 120, $color_white, $font, "Diamonds: " .$row->Coins);
    imagepng($im); 
    imagedestroy($im); 
} else echo('Username is not in our database. Please try again.'); //Username in Database not exist
?>